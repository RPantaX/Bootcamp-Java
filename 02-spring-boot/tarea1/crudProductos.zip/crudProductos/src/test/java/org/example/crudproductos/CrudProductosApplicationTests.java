package org.example.crudproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
